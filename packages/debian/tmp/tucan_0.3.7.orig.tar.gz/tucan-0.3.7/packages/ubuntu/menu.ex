?package(tucan):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="tucan" command="/usr/bin/tucan"
