#!/bin/sh

export PYTHONPATH=$GTK_PATH/lib/python2.5/site-packages/PIL:$GTK_PATH/lib/python2.5/site-packages/gtk-2.0:$GTK_PATH/lib/python2.5/site-packages

